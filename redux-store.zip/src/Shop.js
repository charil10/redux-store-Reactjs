import React from "react";
import { useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import { actionCreaters } from "./state/index";

export const Shop = () => {
  const dispatch = useDispatch();
  const { withdrawMoney, depositMoney } = bindActionCreators(
    actionCreaters,
    dispatch
  );

  return (
    <div>
      <h2>your bank something</h2>
      <button className="btn btn-primary" onClick={() => withdrawMoney(100)}>
        -
      </button>
      Add this to cart
      <button className="btn btn-primary" onClick={() => depositMoney(100)}>
        +
      </button>
    </div>
  );
};
export default Shop;
